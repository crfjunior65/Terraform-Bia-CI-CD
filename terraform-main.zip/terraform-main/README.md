# terraform

Files to create a security group, iam role, instance for EC2 on AWS.
